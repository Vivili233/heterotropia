from flask import url_for
current_url=None  #记录当前路由  默认是空

rid=0