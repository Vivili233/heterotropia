# 配置信息文件
# 开发环境
ENV = 'development'
# 调试模式
DEBUG = True

#设置数据库连接
# 数据库系统+链接池：//登录数据库系统的用户名：密码@数据库服务所在的IP地址：数据库服务端口号/数据库的名字
# SQLALCHEMY_DATABASE_URI='mysql+pymysql://root:123456@127.0.0.1:3306/eyeproject'
SQLALCHEMY_DATABASE_URI='mysql+pymysql://root:!12345abC@47.93.119.184:3306/eye_project'



# 跨站请求保护的密钥  也是session的令牌
SECRET_KEY='2345shfowehfwioe3555hfeio'


