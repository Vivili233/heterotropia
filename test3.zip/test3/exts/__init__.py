# 项目的扩展内容
from flask_sqlalchemy import SQLAlchemy

# 创建数据库关系映射对象
db=SQLAlchemy()