a='0.156'
print(type(a))
a=float(a)
print(type(a))
print(a)