from flask_script import Manager
# 导入构建flask应用的方法
from apps import create_app
from flask_migrate import Migrate,MigrateCommand
# 导入数据库
from exts import db
from flask import render_template,request,session,redirect,url_for
import urlpath
# 引入要映射的模型，不然在迁移的时候找不到
from apps.models.blogmodels import  User
#获取app
app=create_app()


# 把app交给manager管理
manager=Manager(app)

# # 设置数据库迁移相关信息
migrate=Migrate(app,db)
# # 将迁移的操作使用指令的形式交给manager
manager.add_command('database',MigrateCommand)

# 设置主路由
@app.route('/')
def index():
    if request.method == 'GET':
        # 使用session存储登录状态 ，这个状态有值
        if session.get('username'):
            print("manage.py 中的 idnex  已登录")
            return redirect(url_for('record.recordindex'))
        else:
            # 到登录
            # 记录一下跳转之前的路由
            urlpath.current_url = url_for('index')
            print("地址：", urlpath.current_url)
            return redirect(url_for('user.login'))
if __name__=='__main__':
    manager.run()
    #app.run(host='0.0.0.0',debug=True)



'''
会话机制

辅助http具有记忆状态cd

cookie    保存在客户端
session   保存在服务器

session  是以字典的形式保存数据
'''


'''
迁移数据库指令
python 项目启动文件名   设置的操作数据库迁移的指令名  init  ---初始化迁移仓库，用于存放每次修改的版本
python manage.py database init
python manage.py database migrate    --- 根据模型生成迁移版本
python manage.py database upgrade    --- 把模型同步到数据库中

'''