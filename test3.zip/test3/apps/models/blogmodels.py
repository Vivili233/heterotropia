# 用户模型

from exts import db


class User(db.Model):
    uid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(20), nullable=False, unique=True)
    password = db.Column(db.String(20), nullable=False)
    phone = db.Column(db.String(20), unique=True)

    def __init__(self, username, password, phone):
        self.username = username
        self.password = password
        self.phone = phone


class Record(db.Model):
    rid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    caseid = db.Column(db.String(30))  # 病例id
    casesource = db.Column(db.String(20))  # 数据类别   门诊患者   住院患者    幼儿园筛查
    name = db.Column(db.String(20))  # 姓名
    gender = db.Column(db.String(5))  # 性别
    age = db.Column(db.String(5))  # 年龄
    idcard = db.Column(db.String(30))  # 身份证号码
    phone = db.Column(db.String(25))  # 手机号码
    registration_number = db.Column(db.String(25))  # 登记号/顺序号
    set_date = db.Column(db.DateTime)  # 创建时间
    change_date = db.Column(db.DateTime)  # 修改时间

    # 现病史
    strabismus_age = db.Column(db.String(5))  # 斜视年龄
    wryneck = db.Column(db.String(5))  # 歪头
    double_vision = db.Column(db.String(5))  # 复视
    operation_history = db.Column(db.String(5))  # 手术史
    operation_details = db.Column(db.String(255))  # 手术史详情
    glasses = db.Column(db.String(255))  # 戴镜史
    amblyopia_treatment_history = db.Column(db.String(5))  # 弱视治疗史
    family_history = db.Column(db.String(5))  # 家族史
    production_history = db.Column(db.String(5))  # 生产史

    # 检查
    check_nakedeye_right = db.Column(db.String(15))  # 裸眼视力 右眼
    check_nakedeye_left = db.Column(db.String(15))  # 裸眼视力 左眼
    correct_righteye = db.Column(db.String(15))  # 矫正视力 右眼
    correct_lefteye = db.Column(db.String(15))  # 矫正视力  左眼
    comtest_right_ds = db.Column(db.String(15))  # 电脑验光  右眼  DS
    comtest_right_dc = db.Column(db.String(15))  # 电脑验光  右眼  DC
    comtest_right_a = db.Column(db.String(15))  # 电脑验光  右眼  A
    comtest_left_ds = db.Column(db.String(15))  # 电脑验光  左眼 DS
    comtest_left_dc = db.Column(db.String(15))  # 电脑验光  左眼 DC
    comtest_left_a = db.Column(db.String(15))  # 电脑验光  左眼  A

    checktest_right_ds= db.Column(db.String(15))  #检影验光  右眼  DS
    checktest_right_dc= db.Column(db.String(15))  #检影验光  右眼  DC
    checktest_right_a= db.Column(db.String(15))  #检影验光  右眼  A
    checktest_left_ds= db.Column(db.String(15))  #检影验光  左眼 DS
    checktest_left_dc= db.Column(db.String(15))  #检影验光  左眼 DC
    checktest_left_a= db.Column(db.String(15))  #检影验光  左眼  A
    sametime_view= db.Column(db.String(5))  #检查  同视机器  同时视
    sametime_view_level= db.Column(db.String(20))  #同时视值类型  水平值
    sametime_view_verticalselect = db.Column(db.String(15))  #同时视值类型  垂直值选择
    sametime_view_vertical= db.Column(db.String(20))  #同时视值类型  垂直值
    near_eyesight= db.Column(db.String(10))  #近方随机点立体视
    far_eyesight= db.Column(db.String(10))  #远方随机点立体视

    control_strength= db.Column(db.String(10))  #控制力
    reflection_light_level_right= db.Column(db.String(15))  # 检查  角膜映光(右眼) 水平值
    reflection_light_verticalselect_right= db.Column(db.String(15))  #检查  角膜映光(右眼) 垂直值 选择
    reflection_light_vertical_right = db.Column(db.String(15))  #角膜映光(右眼) 垂直值
    reflection_light_level_left = db.Column(db.String(15))  #检查  角膜映光(左眼) 水平值
    reflection_light_verticalselect_left = db.Column(db.String(15))  # 检查  角膜映光(左眼) 垂直值 选择
    reflection_light_vertical_left= db.Column(db.String(15))  #检查  角膜映光(左眼) 垂直值
    three_near_zhijiao= db.Column(db.String(15))  #三棱镜  视近(直角)
    three_far_zhijiao= db.Column(db.String(15))  #三棱镜  视远(直角)
    three_near_dengyao= db.Column(db.String(15))  #三棱镜 视近(等腰)
    three_far_dengyao= db.Column(db.String(15))  #三棱镜  视远(等腰)
    chuizhi_three_select = db.Column(db.String(15))  #三棱镜  垂直三棱镜 选择
    chuizhi_three= db.Column(db.String(15))  #三棱镜 垂直三棱镜
    three_k= db.Column(db.String(15))  #三棱镜  K法
    # 眼球运动
    radiooptions_righteye= db.Column(db.String(5))  #检查 眼球运动右眼 是否正常
    waizhi_right= db.Column(db.String(5))  #眼球运动  右眼 外直肌
    neizhi_right= db.Column(db.String(5))  #眼球运动 右眼 内直肌
    shangzhi_right= db.Column(db.String(5))  #眼球运动 右眼  上直肌
    xiazhi_right= db.Column(db.String(5))  #眼球运动 右眼  下直肌
    shangxie_right= db.Column(db.String(5))  #眼球运动 右眼  上斜肌
    xiaxie_right= db.Column(db.String(5))  #眼球运动 右眼   下斜肌
    radiooptions_lefteye = db.Column(db.String(5))  #眼球运动  左眼  是否正常
    waizhi_left= db.Column(db.String(5))  #眼球运动 左眼  外直肌
    neizhi_left= db.Column(db.String(5))  #眼球运动 左眼   内直肌
    shangzhi_left = db.Column(db.String(5))  #眼球运动 左眼  上直肌
    xiazhi_left= db.Column(db.String(5))  #眼球运动 左眼  下直肌
    shangxie_left= db.Column(db.String(5))  #眼球运动 左眼  上斜肌
    xiaxie_left= db.Column(db.String(5))  #眼球运动 左眼   下斜肌

    #斜视类型
    yinxie = db.Column(db.String(10))  #诊断 斜视类型  隐斜视
    neixie= db.Column(db.String(30))  #诊断 斜视类型  内斜视
    waixie = db.Column(db.String(45))  #诊断 斜视类型  外斜视
    avxie= db.Column(db.String(30))  #诊断 斜视类型  A-V型斜视
    chuizhixuanzhuan= db.Column(db.String(30))  #诊断 斜视类型  垂直旋转性斜视
    teshuxie= db.Column(db.String(45))  #诊断 斜视类型  特殊类型斜视
    zhongshuxie= db.Column(db.String(20))  #诊断 斜视类型  中枢性麻痹性斜视
    eyezhenchan= db.Column(db.String(10))  #诊断 斜视类型  眼球震颤
    eyexie_other= db.Column(db.String(10))  #诊断 斜视类型  其他

    #手术设计
    shoushu_way_waizhi_right= db.Column(db.String(10))  #手术设计 右眼  外直肌手术  方式
    shoushu_liangzhi_waizhi_right= db.Column(db.String(10))  #手术设计 右眼  外直肌手术  量值
    shoushu_way_neizhi_right= db.Column(db.String(10))  #手术设计 右眼  方式  内直肌手术
    shoushu_liangzhi_neizhi_right= db.Column(db.String(10))  #手术设计 右眼  量值  内直肌手术
    shoushu_way_shangzhi_right= db.Column(db.String(10))  #手术设计 右眼  方式  上直肌手术
    shoushu_liangzhi_shangzhi_right= db.Column(db.String(10))  #手术设计 右眼  量值  上直肌手术
    shoushu_way_xiazhi_right= db.Column(db.String(10))  #手术设计 右眼  方式  下直肌手术
    shoushu_liangzhi_xiazhi_right= db.Column(db.String(10))  #手术设计 右眼  量值  下直肌手术
    shoushu_way_shangxie_right = db.Column(db.String(10))  #手术设计 右眼  方式  上斜肌手术
    shoushu_liangzhi_shangxie_right= db.Column(db.String(10))  #手术设计 右眼  量值  上斜肌手术
    shoushu_way_xiaxie_right= db.Column(db.String(10))  #手术设计 右眼  方式  下斜肌手术
    shoushu_liangzhi_xiaxie_right= db.Column(db.String(10))  #手术设计 右眼  量值  下斜肌手术

    shoushu_way_waizhi_left= db.Column(db.String(10))  #手术设计 左眼  外直肌手术  方式
    shoushu_liangzhi_waizhi_left= db.Column(db.String(10))  #手术设计 左眼  外直肌手术  量值
    shoushu_way_neizhi_left= db.Column(db.String(10))  #手术设计 左眼  方式  内直肌手术
    shoushu_liangzhi_neizhi_left= db.Column(db.String(10))  # 手术设计 左眼  量值  内直肌手术
    shoushu_way_shangzhi_left= db.Column(db.String(10))  # 手术设计 左眼  方式  上直肌手术
    shoushu_liangzhi_shangzhi_left= db.Column(db.String(10))  #手术设计 左眼  量值  上直肌手术
    shoushu_way_xiazhi_left= db.Column(db.String(10))  #手术设计 左眼  方式  下直肌手术
    shoushu_liangzhi_xiazhi_left= db.Column(db.String(10))  #手术设计 左眼  量值  下直肌手术
    shoushu_way_shangxie_left= db.Column(db.String(10))  #手术设计 左眼  方式  上斜肌手术
    shoushu_liangzhi_shangxie_left= db.Column(db.String(10))  #手术设计 左眼  量值  上斜肌手术
    shoushu_way_xiaxie_left = db.Column(db.String(10))  #手术设计 左眼  方式  下斜肌手术
    shoushu_liangzhi_xiaxie_left= db.Column(db.String(10))  #手术设计 左眼  量值  下斜肌手术

    # 出院
    out_near_view= db.Column(db.String(10))  #出院  近方随机点立体视
    out_far_view= db.Column(db.String(10))  # 出院 远方随机点立体视


    out_jiaomo_shuiping= db.Column(db.String(15))  #出院  角膜映光  水平值
    out_jiaomo_chuizhiselect= db.Column(db.String(15))  #出院  角膜映光  垂直选择
    out_jiaomo_chuizhi= db.Column(db.String(15))  #出院  角膜映光 垂直
    out_three_near= db.Column(db.String(15))  #出院 三棱镜 视近
    out_three_far= db.Column(db.String(15))  #出院  三棱镜 视远

    out_tongshi_select = db.Column(db.String(15))  #出院  同时视
    out_tongshi_shuiping= db.Column(db.String(15))  #出院  同时视值类型   水平值
    out_tongshi_chuizhiselect= db.Column(db.String(15))  #出院 同时视值类型 垂直选择
    out_tongshi_chuizhi = db.Column(db.String(15))  #出院  同时视值类型  垂直

    out_zhengchang_select_right= db.Column(db.String(15))  #出院 眼球运动右眼
    out_waizhi_right= db.Column(db.String(15))  #出院 眼球运动右眼 外直肌
    out_neizhi_right= db.Column(db.String(15))  #出院  眼球运动右眼 内直肌
    out_shangzhi_right= db.Column(db.String(15))  #出院  眼球运动右眼   上直肌
    out_xiazhi_right= db.Column(db.String(15))  #出院  眼球运动右眼  下直肌
    out_shangxie_right= db.Column(db.String(15))  #出院  眼球运动右眼  上斜肌
    out_xiaxie_right= db.Column(db.String(15))  #出院  眼球运动右眼  下斜肌
    out_zhengchang_select_left = db.Column(db.String(15))  #出院 眼球运动左眼
    out_waizhi_left= db.Column(db.String(15))  #出院 眼球运动左眼 外直肌
    out_neizhi_left= db.Column(db.String(15))  #出院  眼球运动左眼 内直肌
    out_shangzhi_left= db.Column(db.String(15))  #出院  眼球运动左眼   上直肌
    out_xiazhi_left= db.Column(db.String(15))  #出院  眼球运动左眼  下直肌
    out_shangxie_left= db.Column(db.String(15))  #出院  眼球运动左眼  上斜肌
    out_xiaxie_left= db.Column(db.String(15))  #出院  眼球运动左眼  下斜肌

    suifang_time= db.Column(db.String(50))  #随访时间
    note_beizhu= db.Column(db.Text)  #备注

    def __init__(self, caseid, casesource, name, gender, age, idcard, phone, registration_number, set_date,
                 change_date, strabismus_age, wryneck, double_vision, operation_history, operation_details, glasses,
                 amblyopia_treatment_history,family_history, production_history,check_nakedeye_right,check_nakedeye_left,
                 correct_righteye,correct_lefteye,comtest_right_ds,comtest_right_dc,comtest_right_a,comtest_left_ds,comtest_left_dc,
                 comtest_left_a,checktest_right_ds,checktest_right_dc,checktest_right_a,checktest_left_ds,checktest_left_dc,checktest_left_a,
                 sametime_view,sametime_view_level,sametime_view_verticalselect,sametime_view_vertical,near_eyesight,far_eyesight,control_strength,
                 reflection_light_level_right,reflection_light_verticalselect_right,reflection_light_vertical_right,reflection_light_level_left
                 ,reflection_light_verticalselect_left,reflection_light_vertical_left,three_near_zhijiao,three_far_zhijiao,three_near_dengyao
                 ,three_far_dengyao,chuizhi_three_select,chuizhi_three,three_k,radiooptions_righteye,waizhi_right,neizhi_right,shangzhi_right,xiazhi_right
                 ,shangxie_right,xiaxie_right,radiooptions_lefteye,waizhi_left,neizhi_left,shangzhi_left,xiazhi_left,shangxie_left,xiaxie_left,yinxie
                 ,neixie,waixie,avxie,chuizhixuanzhuan,teshuxie,zhongshuxie,eyezhenchan,eyexie_other,shoushu_way_waizhi_right,shoushu_liangzhi_waizhi_right
                 ,shoushu_way_neizhi_right,shoushu_liangzhi_neizhi_right,shoushu_way_shangzhi_right,shoushu_liangzhi_shangzhi_right,shoushu_way_xiazhi_right
                 ,shoushu_liangzhi_xiazhi_right,shoushu_way_shangxie_right,shoushu_liangzhi_shangxie_right,shoushu_way_xiaxie_right,shoushu_liangzhi_xiaxie_right
                 ,shoushu_way_waizhi_left,shoushu_liangzhi_waizhi_left,shoushu_way_neizhi_left,shoushu_liangzhi_neizhi_left,shoushu_way_shangzhi_left,shoushu_liangzhi_shangzhi_left
                 ,shoushu_way_xiazhi_left,shoushu_liangzhi_xiazhi_left,shoushu_way_shangxie_left,shoushu_liangzhi_shangxie_left,shoushu_way_xiaxie_left,shoushu_liangzhi_xiaxie_left
                 ,out_near_view,out_far_view,out_jiaomo_shuiping,out_jiaomo_chuizhiselect,out_jiaomo_chuizhi,out_three_near,out_three_far,out_tongshi_select,out_tongshi_shuiping
                 ,out_tongshi_chuizhiselect,out_tongshi_chuizhi,out_zhengchang_select_right,out_waizhi_right,out_neizhi_right,out_shangzhi_right,out_xiazhi_right
                 ,out_shangxie_right,out_xiaxie_right,out_zhengchang_select_left,out_waizhi_left,out_neizhi_left,out_shangzhi_left,out_xiazhi_left,out_shangxie_left
                 ,out_xiaxie_left,suifang_time,note_beizhu):
        self.caseid = caseid
        self.casesource = casesource
        self.name = name
        self.gender = gender
        self.age = age
        self.idcard = idcard
        self.phone = phone
        self.registration_number = registration_number
        self.set_date = set_date
        self.change_date = change_date
        # 现病史
        self.strabismus_age = strabismus_age
        self.wryneck = wryneck
        self.double_vision = double_vision
        self.operation_history = operation_history
        self.operation_details = operation_details
        self.glasses = glasses
        self.amblyopia_treatment_history = amblyopia_treatment_history
        self.family_history = family_history
        self.production_history = production_history
        self.check_nakedeye_right =check_nakedeye_right
        self.check_nakedeye_left=check_nakedeye_left
        self.correct_righteye =correct_righteye
        self.correct_lefteye =correct_lefteye
        self.comtest_right_ds =comtest_right_ds
        self.comtest_right_dc =comtest_right_dc
        self.comtest_right_a =comtest_right_a
        self.comtest_left_ds =comtest_left_ds
        self.comtest_left_dc =comtest_left_dc
        self.comtest_left_a =comtest_left_a
        self.checktest_right_ds =checktest_right_ds
        self.checktest_right_dc =checktest_right_dc
        self.checktest_right_a =checktest_right_a
        self.checktest_left_ds =checktest_left_ds
        self.checktest_left_dc =checktest_left_dc
        self.checktest_left_a =checktest_left_a
        self.sametime_view =sametime_view
        self.sametime_view_level =sametime_view_level
        self.sametime_view_verticalselect =sametime_view_verticalselect
        self.sametime_view_vertical=sametime_view_vertical
        self.near_eyesight=near_eyesight
        self.far_eyesight =far_eyesight
        self.control_strength =control_strength
        self.reflection_light_level_right =reflection_light_level_right
        self.reflection_light_verticalselect_right =reflection_light_verticalselect_right
        self.reflection_light_vertical_right =reflection_light_vertical_right
        self.reflection_light_level_left =reflection_light_level_left
        self.reflection_light_verticalselect_left =reflection_light_verticalselect_left
        self.reflection_light_vertical_left =reflection_light_vertical_left

        self.three_near_zhijiao =three_near_zhijiao
        self.three_far_zhijiao =three_far_zhijiao
        self.three_near_dengyao =three_near_dengyao
        self.three_far_dengyao =three_far_dengyao
        self.chuizhi_three_select =chuizhi_three_select
        self.chuizhi_three =chuizhi_three
        self.three_k =three_k
        self.radiooptions_righteye =radiooptions_righteye
        self.waizhi_right =waizhi_right
        self.neizhi_right =neizhi_right
        self.shangzhi_right =shangzhi_right
        self.xiazhi_right =xiazhi_right
        self.shangxie_right=shangxie_right
        self.xiaxie_right =xiaxie_right
        self.radiooptions_lefteye =radiooptions_lefteye
        self.waizhi_left =waizhi_left
        self.neizhi_left =neizhi_left
        self.shangzhi_left =shangzhi_left
        self.xiazhi_left =xiazhi_left
        self.shangxie_left =shangxie_left
        self.xiaxie_left =xiaxie_left
        self.yinxie =yinxie
        self.neixie =neixie
        self.waixie =waixie
        self.avxie =avxie
        self.chuizhixuanzhuan =chuizhixuanzhuan
        self.teshuxie =teshuxie
        self.zhongshuxie =zhongshuxie
        self.eyezhenchan =eyezhenchan
        self.eyexie_other =eyexie_other
        self.shoushu_way_waizhi_right =shoushu_way_waizhi_right
        self.shoushu_liangzhi_waizhi_right =shoushu_liangzhi_waizhi_right
        self.shoushu_way_neizhi_right =shoushu_way_neizhi_right
        self.shoushu_liangzhi_neizhi_right =shoushu_liangzhi_neizhi_right
        self.shoushu_way_shangzhi_right =shoushu_way_shangzhi_right
        self.shoushu_liangzhi_shangzhi_right =shoushu_liangzhi_shangzhi_right
        self.shoushu_way_xiazhi_right =shoushu_way_xiazhi_right
        self.shoushu_liangzhi_xiazhi_right =shoushu_liangzhi_xiazhi_right
        self.shoushu_way_shangxie_right =shoushu_way_shangxie_right
        self.shoushu_liangzhi_shangxie_right =shoushu_liangzhi_shangxie_right
        self.shoushu_way_xiaxie_right =shoushu_way_xiaxie_right
        self.shoushu_liangzhi_xiaxie_right =shoushu_liangzhi_xiaxie_right
        self.shoushu_way_waizhi_left =shoushu_way_waizhi_left
        self.shoushu_liangzhi_waizhi_left =shoushu_liangzhi_waizhi_left
        self.shoushu_way_neizhi_left =shoushu_way_neizhi_left
        self.shoushu_liangzhi_neizhi_left =shoushu_liangzhi_neizhi_left
        self.shoushu_way_shangzhi_left =shoushu_way_shangzhi_left
        self.shoushu_liangzhi_shangzhi_left =shoushu_liangzhi_shangzhi_left
        self.shoushu_way_xiazhi_left =shoushu_way_xiazhi_left
        self.shoushu_liangzhi_xiazhi_left =shoushu_liangzhi_xiazhi_left
        self.shoushu_way_shangxie_left =shoushu_way_shangxie_left
        self.shoushu_liangzhi_shangxie_left =shoushu_liangzhi_shangxie_left
        self.shoushu_way_xiaxie_left =shoushu_way_xiaxie_left
        self.shoushu_liangzhi_xiaxie_left =shoushu_liangzhi_xiaxie_left
        self.out_near_view =out_near_view
        self.out_far_view =out_far_view
        self.out_jiaomo_shuiping =out_jiaomo_shuiping
        self.out_jiaomo_chuizhiselect =out_jiaomo_chuizhiselect
        self.out_jiaomo_chuizhi =out_jiaomo_chuizhi
        self.out_three_near =out_three_near
        self.out_three_far =out_three_far
        self.out_tongshi_select =out_tongshi_select
        self.out_tongshi_shuiping =out_tongshi_shuiping
        self.out_tongshi_chuizhiselect =out_tongshi_chuizhiselect
        self.out_tongshi_chuizhi =out_tongshi_chuizhi
        self.out_zhengchang_select_right =out_zhengchang_select_right
        self.out_waizhi_right =out_waizhi_right
        self.out_neizhi_right =out_neizhi_right
        self.out_shangzhi_right =out_shangzhi_right
        self.out_xiazhi_right =out_xiazhi_right
        self.out_shangxie_right =out_shangxie_right
        self.out_xiaxie_right =out_xiaxie_right
        self.out_zhengchang_select_left =out_zhengchang_select_left
        self.out_waizhi_left =out_waizhi_left
        self.out_neizhi_left =out_neizhi_left
        self.out_shangzhi_left =out_shangzhi_left
        self.out_xiazhi_left =out_xiazhi_left
        self.out_shangxie_left =out_shangxie_left
        self.out_xiaxie_left =out_xiaxie_left
        self.suifang_time =suifang_time
        self.note_beizhu =note_beizhu

        #  如果已经迁移过一次数据库用下面的命令    否则勇manage_test 中的命令
# python manage.py database migrate    --- 根据模型生成迁移版本
# python manage.py database upgrade    --- 把模型同步到数据库中
