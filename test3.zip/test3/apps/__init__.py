# 创建flsk应用app
from flask import Flask
# 导入配置文件
import settings
# 导入数据库
from exts import  db
#from flask_wtf import CsrfProtect
#导入蓝图板块
from apps.views.user import user_bp
from apps.views.record import record_bp
# 声明一个方法 ，创建app
def create_app():
    # 修改template_folder是因为创建flask应用对象的位置发生了变化，内有和模板文件夹在同一目录下
    app=Flask(__name__,template_folder='../templates',static_folder='../static')
    # 设置应用的配置信息,在配置文件中加载配置信息
    app.config.from_pyfile('../settings.py')

    # 将数据库与项目关联
    db.init_app(app)

    # # 创建保护对象，保护app
    # CsrfProtect(app)

    #注册蓝图
    app.register_blueprint(user_bp)
    app.register_blueprint(record_bp)
    return app