from flask import Blueprint, request, session, redirect, url_for, render_template
from sqlalchemy import or_

import urlpath
from apps.models.blogmodels import Record
from exts import db
import datetime

record_bp = Blueprint('record', __name__, url_prefix='/record')


# 1.创建record

@record_bp.route('/publish/', methods=['GET', 'POST'])
def publish():
    if request.method == 'GET':
        # 使用session存储登录状态
        if session.get('username'):
            return render_template('publish.html')
        else:
            # 到登录
            # 记录一下跳转之前的路由
            urlpath.current_url = url_for('record.publish')
            print(urlpath.current_url)
            return redirect(url_for('user.login'))
    else:
        print(request.form)
        # 获取信息
        caseid = '0'
        patient_source = request.form.get('patient_source')
        input_name = request.form.get('input_name')
        patient_gender = request.form.get('patient_gender')
        input_age = request.form.get('input_age')
        cardid = request.form.get('cardid')
        phone = request.form.get('phone')
        registration_number = request.form.get('registration_number')
        set_date = datetime.datetime.now()
        change_date = datetime.datetime.now()

        # 现病史
        strabismus_age = request.form.get('strabismus_age')

        wryneck = request.form.get('wryneck')
        double_vision = request.form.get('double_vision')
        operation_history = request.form.get('operation_history')
        operation_details = request.form.get('operation_details')
        glasses = request.form.get('glasses')
        amblyopia_treatment_history = request.form.get('amblyopia_treatment_history')

        family_history = request.form.get('family_history')
        production_history = request.form.get('production_history')
        check_nakedeye_right = request.form.get('check_nakedeye_right')
        check_nakedeye_left = request.form.get('check_nakedeye_left')
        correct_righteye = request.form.get('correct_righteye')
        correct_lefteye = request.form.get('correct_lefteye')

        comtest_right_ds = request.form.get('comtest_right_ds')
        comtest_right_dc = request.form.get('comtest_right_dc')
        comtest_right_a = request.form.get('comtest_right_a')
        comtest_left_ds = request.form.get('comtest_left_ds')
        comtest_left_dc = request.form.get('comtest_left_dc')
        comtest_left_a = request.form.get('comtest_left_a')
        checktest_right_ds = request.form.get('checktest_right_ds')
        checktest_right_dc = request.form.get('checktest_right_dc')
        checktest_right_a = request.form.get('checktest_right_a')
        checktest_left_ds = request.form.get('checktest_left_ds')
        checktest_left_dc = request.form.get('checktest_left_dc')
        checktest_left_a = request.form.get('checktest_left_a')
        sametime_view = request.form.get('sametime_view')
        sametime_view_level = request.form.get('sametime_view_level')
        sametime_view_verticalselect = request.form.get('sametime_view_verticalselect')
        sametime_view_vertical = request.form.get('sametime_view_vertical')
        near_eyesight = request.form.get('near_eyesight')
        far_eyesight = request.form.get('far_eyesight')
        control_strength = request.form.get('control_strength')
        reflection_light_level_right = request.form.get('reflection_light_level_right')
        reflection_light_verticalselect_right = request.form.get('reflection_light_verticalselect_right')
        reflection_light_vertical_right = request.form.get('reflection_light_vertical_right')
        reflection_light_level_left = request.form.get('reflection_light_level_left')
        reflection_light_verticalselect_left = request.form.get('reflection_light_verticalselect_left')
        reflection_light_vertical_left = request.form.get('reflection_light_vertical_left')

        three_near_zhijiao = request.form.get('three_near_zhijiao')
        three_far_zhijiao = request.form.get('three_far_zhijiao')
        three_near_dengyao = request.form.get('three_near_dengyao')
        three_far_dengyao = request.form.get('three_far_dengyao')
        chuizhi_three_select = request.form.get('chuizhi_three_select')
        chuizhi_three = request.form.get('chuizhi_three')
        three_k = request.form.get('three_k')
        radiooptions_righteye = request.form.get('radiooptions_righteye')
        waizhi_right = request.form.get('waizhi_right')
        neizhi_right = request.form.get('neizhi_right')
        shangzhi_right = request.form.get('shangzhi_right')
        xiazhi_right = request.form.get('xiazhi_right')
        shangxie_right = request.form.get('shangxie_right')
        xiaxie_right = request.form.get('xiaxie_right')
        radiooptions_lefteye = request.form.get('radiooptions_lefteye')
        waizhi_left = request.form.get('waizhi_left')
        neizhi_left = request.form.get('neizhi_left')
        shangzhi_left = request.form.get('shangzhi_left')
        xiazhi_left = request.form.get('xiazhi_left')
        shangxie_left = request.form.get('shangxie_left')
        xiaxie_left = request.form.get('xiaxie_left')
        yinxie = request.form.get('yinxie')
        neixie = request.form.get('neixie')
        waixie = request.form.get('waixie')
        avxie = request.form.get('avxie')
        chuizhixuanzhuan = request.form.get('chuizhixuanzhuan')
        teshuxie = request.form.get('teshuxie')
        zhongshuxie = request.form.get('zhongshuxie')
        eyezhenchan = request.form.get('eyezhenchan')
        eyexie_other = request.form.get('eyexie_other')
        shoushu_way_waizhi_right = request.form.get('shoushu_way_waizhi_right')
        shoushu_liangzhi_waizhi_right = request.form.get('shoushu_liangzhi_waizhi_right')
        shoushu_way_neizhi_right = request.form.get('shoushu_way_neizhi_right')
        shoushu_liangzhi_neizhi_right = request.form.get('shoushu_liangzhi_neizhi_right')
        shoushu_way_shangzhi_right = request.form.get('shoushu_way_shangzhi_right')
        shoushu_liangzhi_shangzhi_right = request.form.get('shoushu_liangzhi_shangzhi_right')
        shoushu_way_xiazhi_right = request.form.get('shoushu_way_xiazhi_right')
        shoushu_liangzhi_xiazhi_right = request.form.get('shoushu_liangzhi_xiazhi_right')
        shoushu_way_shangxie_right = request.form.get('shoushu_way_shangxie_right')
        shoushu_liangzhi_shangxie_right = request.form.get('shoushu_liangzhi_shangxie_right')
        shoushu_way_xiaxie_right = request.form.get('shoushu_way_xiaxie_right')
        shoushu_liangzhi_xiaxie_right = request.form.get('shoushu_liangzhi_xiaxie_right')
        shoushu_way_waizhi_left = request.form.get('shoushu_way_waizhi_left')
        shoushu_liangzhi_waizhi_left = request.form.get('shoushu_liangzhi_waizhi_left')
        shoushu_way_neizhi_left = request.form.get('shoushu_way_neizhi_left')
        shoushu_liangzhi_neizhi_left = request.form.get('shoushu_liangzhi_neizhi_left')
        shoushu_way_shangzhi_left = request.form.get('shoushu_way_shangzhi_left')
        shoushu_liangzhi_shangzhi_left = request.form.get('shoushu_liangzhi_shangzhi_left')
        shoushu_way_xiazhi_left = request.form.get('shoushu_way_xiazhi_left')
        shoushu_liangzhi_xiazhi_left = request.form.get('shoushu_liangzhi_xiazhi_left')
        shoushu_way_shangxie_left = request.form.get('shoushu_way_shangxie_left')
        shoushu_liangzhi_shangxie_left = request.form.get('shoushu_liangzhi_shangxie_left')
        shoushu_way_xiaxie_left = request.form.get('shoushu_way_xiaxie_left')
        shoushu_liangzhi_xiaxie_left = request.form.get('shoushu_liangzhi_xiaxie_left')
        out_near_view = request.form.get('out_near_view')
        out_far_view = request.form.get('out_far_view')
        out_jiaomo_shuiping = request.form.get('out_jiaomo_shuiping')
        out_jiaomo_chuizhiselect = request.form.get('out_jiaomo_chuizhiselect')
        out_jiaomo_chuizhi = request.form.get('out_jiaomo_chuizhi')
        out_three_near = request.form.get('out_three_near')
        out_three_far = request.form.get('out_three_far')
        out_tongshi_select = request.form.get('out_tongshi_select')
        out_tongshi_shuiping = request.form.get('out_tongshi_shuiping')
        out_tongshi_chuizhiselect = request.form.get('out_tongshi_chuizhiselect')
        out_tongshi_chuizhi = request.form.get('out_tongshi_chuizhi')
        out_zhengchang_select_right = request.form.get('out_zhengchang_select_right')
        out_waizhi_right = request.form.get('out_waizhi_right')
        out_neizhi_right = request.form.get('out_neizhi_right')
        out_shangzhi_right = request.form.get('out_shangzhi_right')
        out_xiazhi_right = request.form.get('out_xiazhi_right')
        out_shangxie_right = request.form.get('out_shangxie_right')
        out_xiaxie_right = request.form.get('out_xiaxie_right')
        out_zhengchang_select_left = request.form.get('out_zhengchang_select_left')
        out_waizhi_left = request.form.get('out_waizhi_left')
        out_neizhi_left = request.form.get('out_neizhi_left')
        out_shangzhi_left = request.form.get('out_shangzhi_left')
        out_xiazhi_left = request.form.get('out_xiazhi_left')
        out_shangxie_left = request.form.get('out_shangxie_left')
        out_xiaxie_left = request.form.get('out_xiaxie_left')
        suifang_time = request.form.get('suifang_time')
        note_beizhu = request.form.get('note_beizhu')

        # 创建病例对象
        record = Record(caseid, patient_source, input_name, patient_gender, input_age, cardid, phone,
                        registration_number,
                        set_date, change_date, strabismus_age, wryneck, double_vision, operation_history,
                        operation_details, glasses, amblyopia_treatment_history,
                        family_history, production_history, check_nakedeye_right, check_nakedeye_left,
                        correct_righteye, correct_lefteye, comtest_right_ds, comtest_right_dc, comtest_right_a,
                        comtest_left_ds, comtest_left_dc,
                        comtest_left_a, checktest_right_ds, checktest_right_dc, checktest_right_a, checktest_left_ds,
                        checktest_left_dc, checktest_left_a,
                        sametime_view, sametime_view_level, sametime_view_verticalselect, sametime_view_vertical,
                        near_eyesight, far_eyesight, control_strength,
                        reflection_light_level_right, reflection_light_verticalselect_right,
                        reflection_light_vertical_right, reflection_light_level_left
                        , reflection_light_verticalselect_left, reflection_light_vertical_left, three_near_zhijiao,
                        three_far_zhijiao, three_near_dengyao
                        , three_far_dengyao, chuizhi_three_select, chuizhi_three, three_k, radiooptions_righteye,
                        waizhi_right, neizhi_right, shangzhi_right, xiazhi_right
                        , shangxie_right, xiaxie_right, radiooptions_lefteye, waizhi_left, neizhi_left, shangzhi_left,
                        xiazhi_left, shangxie_left, xiaxie_left, yinxie
                        , neixie, waixie, avxie, chuizhixuanzhuan, teshuxie, zhongshuxie, eyezhenchan, eyexie_other,
                        shoushu_way_waizhi_right, shoushu_liangzhi_waizhi_right
                        , shoushu_way_neizhi_right, shoushu_liangzhi_neizhi_right, shoushu_way_shangzhi_right,
                        shoushu_liangzhi_shangzhi_right, shoushu_way_xiazhi_right
                        , shoushu_liangzhi_xiazhi_right, shoushu_way_shangxie_right, shoushu_liangzhi_shangxie_right,
                        shoushu_way_xiaxie_right, shoushu_liangzhi_xiaxie_right
                        , shoushu_way_waizhi_left, shoushu_liangzhi_waizhi_left, shoushu_way_neizhi_left,
                        shoushu_liangzhi_neizhi_left, shoushu_way_shangzhi_left, shoushu_liangzhi_shangzhi_left
                        , shoushu_way_xiazhi_left, shoushu_liangzhi_xiazhi_left, shoushu_way_shangxie_left,
                        shoushu_liangzhi_shangxie_left, shoushu_way_xiaxie_left, shoushu_liangzhi_xiaxie_left
                        , out_near_view, out_far_view, out_jiaomo_shuiping, out_jiaomo_chuizhiselect,
                        out_jiaomo_chuizhi, out_three_near, out_three_far, out_tongshi_select, out_tongshi_shuiping
                        , out_tongshi_chuizhiselect, out_tongshi_chuizhi, out_zhengchang_select_right, out_waizhi_right,
                        out_neizhi_right, out_shangzhi_right, out_xiazhi_right
                        , out_shangxie_right, out_xiaxie_right, out_zhengchang_select_left, out_waizhi_left,
                        out_neizhi_left, out_shangzhi_left, out_xiazhi_left, out_shangxie_left
                        , out_xiaxie_left, suifang_time, note_beizhu)
        # 添加到数据库
        db.session.add(record)
        # 提交
        db.session.commit()

        return redirect(url_for('index'))


# 首页的内容展示
@record_bp.route('/index/')
def recordindex():
    # records=Record.query.order_by(Record.set_date.desc()).all()
    # 分页显示 page 当前页面  perpage 每页的数据条数   返回的是根据设定的页码和每页返回的数据创建的一个页码器对象
    # items---当前页下的数据元素集合是什么
    # page--- 当前页码
    # has_prev判断是否有上一页
    # ha_next 判断是否有下一页
    # prev_num  上一页的页数
    # next_num 下一页的页码
    # iter_pages()  页码器中的页码数目
    # 获取页码
    curpage = int(request.args.get('curpage', 1))  # 当没有curpage传递的时候，拿的是第一页的数据，也就是点击首页的时候，没有curpage传递
    paginate = Record.query.order_by(Record.set_date.desc()).paginate(page=curpage, per_page=15)

    return render_template('index.html', paginate=paginate)


# 删除病例信息
@record_bp.route('/delete/', methods=['GET', 'POST'])
def delete():
    print(request.args)
    rid = request.args.get('record_rid')
    print(rid)
    print(type(rid))
    # 根据rid获取要删除的病例对象
    record = Record.query.get(rid)
    db.session.delete(record)
    db.session.commit()
    return redirect(url_for('index'))


# 修改病例信息
@record_bp.route('/change/', methods=['GET', 'POST'])
def change():
    if request.method == 'GET':
        print(request.args)
        rid = request.args.get('record_rid')
        urlpath.rid = rid
        # 根据rid获取要修改的病例对象
        record = Record.query.get(rid)
        print('输出年龄', record.age)
        print('输出名字', record.name)
        return render_template('change.html', record=record)

    else:
        print('返回', request.form)
        rid = urlpath.rid
        record = Record.query.get(rid)



        record.casesource = request.form.get('patient_source')
        record.name = request.form.get('input_name')
        record.gender = request.form.get('patient_gender')
        record.age = request.form.get('input_age')
        record.idcard = request.form.get('cardid')
        record.phone = request.form.get('phone')
        record.registration_number = request.form.get('registration_number')
        record.change_date = datetime.datetime.now()

        # 现在病史
        record.strabismus_age = request.form.get('strabismus_age')

        record.wryneck = request.form.get('wryneck')
        record.double_vision = request.form.get('double_vision')
        record.operation_history = request.form.get('operation_history')
        record.operation_details = request.form.get('operation_details')
        record.glasses = request.form.get('glasses')
        record.amblyopia_treatment_history = request.form.get('amblyopia_treatment_history')

        record.family_history = request.form.get('family_history')
        record.production_history = request.form.get('production_history')

        #检查
        record.check_nakedeye_right = request.form.get('check_nakedeye_right')
        record.check_nakedeye_left = request.form.get('check_nakedeye_left')
        record.correct_righteye = request.form.get('correct_righteye')
        record.correct_lefteye = request.form.get('correct_lefteye')

        record.comtest_right_ds = request.form.get('comtest_right_ds')
        record.comtest_right_dc = request.form.get('comtest_right_dc')
        record.comtest_right_a = request.form.get('comtest_right_a')
        record.comtest_left_ds = request.form.get('comtest_left_ds')
        record.comtest_left_dc = request.form.get('comtest_left_dc')
        record.comtest_left_a = request.form.get('comtest_left_a')
        record.checktest_right_ds = request.form.get('checktest_right_ds')
        record.checktest_right_dc = request.form.get('checktest_right_dc')
        record.checktest_right_a = request.form.get('checktest_right_a')
        record.checktest_left_ds = request.form.get('checktest_left_ds')
        record.checktest_left_dc = request.form.get('checktest_left_dc')
        record.checktest_left_a = request.form.get('checktest_left_a')
        record.sametime_view = request.form.get('sametime_view')
        record.sametime_view_level = request.form.get('sametime_view_level')
        record.sametime_view_verticalselect = request.form.get('sametime_view_verticalselect')
        record.sametime_view_vertical = request.form.get('sametime_view_vertical')
        record.near_eyesight = request.form.get('near_eyesight')
        record.far_eyesight = request.form.get('far_eyesight')
        record.control_strength = request.form.get('control_strength')
        record.reflection_light_level_right = request.form.get('reflection_light_level_right')
        record.reflection_light_verticalselect_right = request.form.get('reflection_light_verticalselect_right')
        record.reflection_light_vertical_right = request.form.get('reflection_light_vertical_right')
        record.reflection_light_level_left = request.form.get('reflection_light_level_left')
        record.reflection_light_verticalselect_left = request.form.get('reflection_light_verticalselect_left')
        record.reflection_light_vertical_left = request.form.get('reflection_light_vertical_left')

        record.three_near_zhijiao = request.form.get('three_near_zhijiao')
        record.three_far_zhijiao = request.form.get('three_far_zhijiao')
        record.three_near_dengyao = request.form.get('three_near_dengyao')
        record.three_far_dengyao = request.form.get('three_far_dengyao')
        record.chuizhi_three_select = request.form.get('chuizhi_three_select')
        record.chuizhi_three = request.form.get('chuizhi_three')
        record.three_k = request.form.get('three_k')
        record.radiooptions_righteye = request.form.get('radiooptions_righteye')
        record.waizhi_right = request.form.get('waizhi_right')
        record.neizhi_right = request.form.get('neizhi_right')
        record.shangzhi_right = request.form.get('shangzhi_right')
        record.xiazhi_right = request.form.get('xiazhi_right')
        record.shangxie_right = request.form.get('shangxie_right')
        record.xiaxie_right = request.form.get('xiaxie_right')
        record.radiooptions_lefteye = request.form.get('radiooptions_lefteye')
        record.waizhi_left = request.form.get('waizhi_left')
        record.neizhi_left = request.form.get('neizhi_left')
        record.shangzhi_left = request.form.get('shangzhi_left')
        record.xiazhi_left = request.form.get('xiazhi_left')
        record.shangxie_left = request.form.get('shangxie_left')
        record.xiaxie_left = request.form.get('xiaxie_left')
        record.yinxie = request.form.get('yinxie')
        record.neixie = request.form.get('neixie')
        record.waixie = request.form.get('waixie')
        record.avxie = request.form.get('avxie')
        record.chuizhixuanzhuan = request.form.get('chuizhixuanzhuan')
        record.teshuxie = request.form.get('teshuxie')
        record.zhongshuxie = request.form.get('zhongshuxie')
        record.eyezhenchan = request.form.get('eyezhenchan')
        record.eyexie_other = request.form.get('eyexie_other')
        record.shoushu_way_waizhi_right = request.form.get('shoushu_way_waizhi_right')
        record.shoushu_liangzhi_waizhi_right = request.form.get('shoushu_liangzhi_waizhi_right')
        record.shoushu_way_neizhi_right = request.form.get('shoushu_way_neizhi_right')
        record.shoushu_liangzhi_neizhi_right = request.form.get('shoushu_liangzhi_neizhi_right')
        record.shoushu_way_shangzhi_right = request.form.get('shoushu_way_shangzhi_right')
        record.shoushu_liangzhi_shangzhi_right = request.form.get('shoushu_liangzhi_shangzhi_right')
        record.shoushu_way_xiazhi_right = request.form.get('shoushu_way_xiazhi_right')
        record.shoushu_liangzhi_xiazhi_right = request.form.get('shoushu_liangzhi_xiazhi_right')
        record.shoushu_way_shangxie_right = request.form.get('shoushu_way_shangxie_right')
        record.shoushu_liangzhi_shangxie_right = request.form.get('shoushu_liangzhi_shangxie_right')
        record.shoushu_way_xiaxie_right = request.form.get('shoushu_way_xiaxie_right')
        record.shoushu_liangzhi_xiaxie_right = request.form.get('shoushu_liangzhi_xiaxie_right')
        record.shoushu_way_waizhi_left = request.form.get('shoushu_way_waizhi_left')
        record.shoushu_liangzhi_waizhi_left = request.form.get('shoushu_liangzhi_waizhi_left')
        record.shoushu_way_neizhi_left = request.form.get('shoushu_way_neizhi_left')
        record.shoushu_liangzhi_neizhi_left = request.form.get('shoushu_liangzhi_neizhi_left')
        record.shoushu_way_shangzhi_left = request.form.get('shoushu_way_shangzhi_left')
        record.shoushu_liangzhi_shangzhi_left = request.form.get('shoushu_liangzhi_shangzhi_left')
        record.shoushu_way_xiazhi_left = request.form.get('shoushu_way_xiazhi_left')
        record.shoushu_liangzhi_xiazhi_left = request.form.get('shoushu_liangzhi_xiazhi_left')
        record.shoushu_way_shangxie_left = request.form.get('shoushu_way_shangxie_left')
        record.shoushu_liangzhi_shangxie_left = request.form.get('shoushu_liangzhi_shangxie_left')
        record.shoushu_way_xiaxie_left = request.form.get('shoushu_way_xiaxie_left')
        record.shoushu_liangzhi_xiaxie_left = request.form.get('shoushu_liangzhi_xiaxie_left')
        record.out_near_view = request.form.get('out_near_view')
        record.out_far_view = request.form.get('out_far_view')
        record.out_jiaomo_shuiping = request.form.get('out_jiaomo_shuiping')
        record.out_jiaomo_chuizhiselect = request.form.get('out_jiaomo_chuizhiselect')
        record.out_jiaomo_chuizhi = request.form.get('out_jiaomo_chuizhi')
        record.out_three_near = request.form.get('out_three_near')
        record.out_three_far = request.form.get('out_three_far')
        record.out_tongshi_select = request.form.get('out_tongshi_select')
        record.out_tongshi_shuiping = request.form.get('out_tongshi_shuiping')
        record.out_tongshi_chuizhiselect = request.form.get('out_tongshi_chuizhiselect')
        record.out_tongshi_chuizhi = request.form.get('out_tongshi_chuizhi')
        record.out_zhengchang_select_right = request.form.get('out_zhengchang_select_right')
        record.out_waizhi_right = request.form.get('out_waizhi_right')
        record.out_neizhi_right = request.form.get('out_neizhi_right')
        record.out_shangzhi_right = request.form.get('out_shangzhi_right')
        record.out_xiazhi_right = request.form.get('out_xiazhi_right')
        record.out_shangxie_right = request.form.get('out_shangxie_right')
        record.out_xiaxie_right = request.form.get('out_xiaxie_right')
        record.out_zhengchang_select_left = request.form.get('out_zhengchang_select_left')
        record.out_waizhi_left = request.form.get('out_waizhi_left')
        record.out_neizhi_left = request.form.get('out_neizhi_left')
        record.out_shangzhi_left = request.form.get('out_shangzhi_left')
        record.out_xiazhi_left = request.form.get('out_xiazhi_left')
        record.out_shangxie_left = request.form.get('out_shangxie_left')
        record.out_xiaxie_left = request.form.get('out_xiaxie_left')
        record.suifang_time = request.form.get('suifang_time')
        record.note_beizhu = request.form.get('note_beizhu')



        db.session.commit()
        return redirect(url_for('index'))


# 查看病例信息
@record_bp.route('/check/', methods=['GET', 'POST'])
def check():
    if request.method == 'GET':
        print(request.args)
        rid = request.args.get('record_rid')
        urlpath.rid = rid
        # 根据rid获取要修改的病例对象
        record = Record.query.get(rid)
        print(record.gender)
        return render_template('check.html', record=record)


# 搜索
@record_bp.route('/search/', methods=['GET', 'POST'])
def search():
    # 使用session存储登录状态
    if session.get('username'):
        print(request.args)
        # 获取搜索内容
        search_content = request.args.get('search')
        # 查询内容是否包含在 。。。
        records = Record.query.filter(
            or_(Record.casesource.contains(search_content), Record.name.contains(search_content),
                Record.gender.contains(search_content), Record.age.contains(search_content),
                Record.registration_number.contains(search_content))).all()
        return render_template('search.html', records=records)
    else:
        # 到登录
        # 记录一下跳转之前的路由
        urlpath.current_url = url_for('record.recordindex')
        print(urlpath.current_url)
        return redirect(url_for('user.login'))
