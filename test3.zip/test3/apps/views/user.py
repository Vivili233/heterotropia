from flask import Blueprint,request,render_template,redirect,url_for,session
from apps.models.blogmodels import User
from exts import db
import urlpath
user_bp=Blueprint('user',__name__,url_prefix='/user')

# 注册
@user_bp.route('/register/',methods=['GET','POST'])
def register():
    if request.method=='GET':
        # 只获取注册页面
        return render_template('register.html')
    else:
        # 获取post提交的数据
        print(f'{request.form}')
        name=request.form.get('username')

        psw = request.form.get('psw')

        phone=request.form.get('phone')

        # 创建对象
        user=User(name,psw,phone)
        #添加
        db.session.add(user)
        #提交
        db.session.commit()
        return redirect(url_for('user.login'))

#检验用户名是否存在
@user_bp.route('/checkname/',methods=['POST'])
def check_name():
    print(request.form)

    # 从前端获取用户名
    username=request.form.get('username')
    # 查询  根据username在数据库中进行查询
    data=User.query.filter(User.username==username).all()
    print(data)
    if data:
        return {'code':2000,'msg':'用户名已存在'}
    else:
        return {'code':2001,'msg':'用户名不存在'}
    return 'ok'


#检验手机号是否被注册
@user_bp.route('/checkphone/',methods=['POST'])
def check_phone():
    print(request.form)

    # 从前端获取用户名
    phone=request.form.get('phone')
    # 查询  根据username在数据库中进行查询
    data=User.query.filter(User.phone==phone).all()
    print(data)
    if data:
        return {'code':2000,'msg':'手机号被注册'}
    else:
        return {'code':2001,'msg':'手机号可用'}
    return 'ok'

#设置登录对应的路由信息
@user_bp.route('/login/',methods=['GET','POST'])
def login():
    if request.method=='GET':
        return render_template('login.html',message='')
    else:
        print(request.form)
        # 提取数据 根据数据查询
        username=request.form.get('username')
        password = request.form.get('psw')

        # 数据的查询
        user=User.query.filter(User.username==username,User.password==password).first()
        print(user)

        if user is None:
            return render_template('login.html',message='用户名或密码错误')
        else:
            # 保存用户的信息，证明是哪个用户登陆的
            session['username']=username   # 把用户名存储
            print(session)
            return redirect(urlpath.current_url)




# 退出登录
@user_bp.route('/exit/')
def exit():
    # 移除掉用户存储的登录状态
    session.pop('username')
    print(session)
    return redirect(url_for('index'))